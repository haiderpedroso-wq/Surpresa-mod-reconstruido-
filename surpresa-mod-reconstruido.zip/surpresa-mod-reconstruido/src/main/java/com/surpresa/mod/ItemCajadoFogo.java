package com.surpresa.mod;

import net.minecraft.block.BlockFire;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.world.World;

/** Cajado de fogo: acende o bloco atingido ou o bloco de apoio. */
public class ItemCajadoFogo extends Item {
    public ItemCajadoFogo() {
        setRegistryName(SurpresaMod.MODID, "cajado_fogo");
        setUnlocalizedName(SurpresaMod.MODID + ".cajado_fogo");
        setCreativeTab(CreativeTabs.COMBAT);
        setMaxStackSize(1);
        setMaxDamage(96);
    }

    @Override
    public ActionResult<ItemStack> onItemRightClick(World world, EntityPlayer player, EnumHand hand) {
        ItemStack stack = player.getHeldItem(hand);
        RayTraceResult hit = player.rayTrace(24.0D, 1.0F);
        if (hit == null || hit.typeOfHit == RayTraceResult.Type.MISS) {
            return new ActionResult<>(EnumActionResult.FAIL, stack);
        }

        if (!world.isRemote) {
            BlockPos target = hit.getBlockPos();
            if (hit.sideHit != null) target = target.offset(hit.sideHit);
            IBlockState state = world.getBlockState(target);
            if (world.isAirBlock(target) && Blocks.FIRE.canPlaceBlockAt(world, target)) {
                world.setBlockState(target, Blocks.FIRE.getDefaultState(), 3);
                stack.damageItem(1, player);
            } else {
                return new ActionResult<>(EnumActionResult.FAIL, stack);
            }
        }
        player.getCooldownTracker().setCooldown(this, 20);
        return new ActionResult<>(EnumActionResult.SUCCESS, stack);
    }
}
