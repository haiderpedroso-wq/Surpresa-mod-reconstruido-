package com.surpresa.mod;

import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;

@Mod.EventBusSubscriber(modid = SurpresaMod.MODID, value = Side.CLIENT)
public class ClientModels {
    @SubscribeEvent
    public static void registerModels(ModelRegistryEvent event) {
        register(ModItems.CAJADO_RAIO);
        register(ModItems.CAJADO_FOGO);
        register(ModItems.FRAGMENTO_ARCANO);
    }

    private static void register(net.minecraft.item.Item item) {
        ModelLoader.setCustomModelResourceLocation(item, 0,
                new ModelResourceLocation(item.getRegistryName(), "inventory"));
    }
}
