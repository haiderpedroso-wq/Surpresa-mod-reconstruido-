package com.surpresa.mod;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;

public class ItemFragmentoArcano extends Item {
    public ItemFragmentoArcano() {
        setRegistryName(SurpresaMod.MODID, "fragmento_arcano");
        setUnlocalizedName(SurpresaMod.MODID + ".fragmento_arcano");
        setCreativeTab(CreativeTabs.MATERIALS);
        setMaxStackSize(64);
    }
}
