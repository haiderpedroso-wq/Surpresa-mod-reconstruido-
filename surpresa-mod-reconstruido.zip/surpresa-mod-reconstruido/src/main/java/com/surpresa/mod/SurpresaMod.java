package com.surpresa.mod;

import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;

@Mod(modid = SurpresaMod.MODID, name = "Surpresa Mod", version = "1.1",
        acceptedMinecraftVersions = "[1.12.2]")
public class SurpresaMod {
    public static final String MODID = "surpresa";

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        MinecraftForge.EVENT_BUS.register(new TreeFellerHandler());
        MinecraftForge.EVENT_BUS.register(new ArcaneDropHandler());
    }
}
