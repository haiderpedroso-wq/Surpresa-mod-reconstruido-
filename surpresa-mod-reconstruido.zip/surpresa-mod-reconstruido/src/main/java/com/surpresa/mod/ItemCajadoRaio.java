package com.surpresa.mod;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class ItemCajadoRaio extends Item {
    public ItemCajadoRaio() {
        setRegistryName(SurpresaMod.MODID, "cajado_raio");
        setUnlocalizedName(SurpresaMod.MODID + ".cajado_raio");
        setCreativeTab(CreativeTabs.COMBAT);
        setMaxStackSize(1);
        setMaxDamage(64);
    }

    @Override
    public ActionResult<ItemStack> onItemRightClick(World world, EntityPlayer player, EnumHand hand) {
        ItemStack stack = player.getHeldItem(hand);
        RayTraceResult hit = player.rayTrace(50.0D, 1.0F);
        if (hit == null || hit.typeOfHit == RayTraceResult.Type.MISS) {
            return new ActionResult<>(EnumActionResult.FAIL, stack);
        }
        if (!world.isRemote) {
            Vec3d v = hit.hitVec;
            world.addWeatherEffect(new EntityLightningBolt(world, v.x, v.y, v.z, false));
            if (!player.capabilities.isCreativeMode) stack.damageItem(1, player);
        }
        player.getCooldownTracker().setCooldown(this, 40);
        return new ActionResult<>(EnumActionResult.SUCCESS, stack);
    }
}
