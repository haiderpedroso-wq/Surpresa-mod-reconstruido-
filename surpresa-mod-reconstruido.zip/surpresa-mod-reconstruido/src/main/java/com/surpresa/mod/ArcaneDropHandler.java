package com.surpresa.mod;

import java.util.Random;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.monster.IMob;
import net.minecraft.item.ItemStack;
import net.minecraftforge.event.entity.living.LivingDropsEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

/** Mobs hostis podem deixar um Fragmento Arcano como drop raro. */
public class ArcaneDropHandler {
    private final Random random = new Random();

    @SubscribeEvent
    public void onLivingDrops(LivingDropsEvent event) {
        EntityLivingBase entity = event.getEntityLiving();
        if (entity.world.isRemote || !(entity instanceof IMob)) return;
        if (random.nextFloat() < 0.12F) {
            event.getDrops().add(new EntityItem(entity.world, entity.posX, entity.posY,
                    entity.posZ, new ItemStack(ModItems.FRAGMENTO_ARCANO)));
        }
    }
}
