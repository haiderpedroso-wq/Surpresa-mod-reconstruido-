package com.surpresa.mod;

import net.minecraft.item.Item;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@Mod.EventBusSubscriber(modid = SurpresaMod.MODID)
public class ModItems {
    public static final Item CAJADO_RAIO = new ItemCajadoRaio();
    public static final Item CAJADO_FOGO = new ItemCajadoFogo();
    public static final Item FRAGMENTO_ARCANO = new ItemFragmentoArcano();

    @SubscribeEvent
    public static void registerItems(RegistryEvent.Register<Item> event) {
        event.getRegistry().registerAll(CAJADO_RAIO, CAJADO_FOGO, FRAGMENTO_ARCANO);
    }
}
