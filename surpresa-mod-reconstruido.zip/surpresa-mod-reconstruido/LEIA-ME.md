# Surpresa Mod 1.12.2 — reconstruído

## Conteúdo
- Cajado do Raio: invoca um raio no bloco/posição apontada (alcance 50, recarga 2 s, durabilidade 64).
- Cajado de Fogo: coloca fogo no bloco apontado ou na face adjacente (alcance 24, recarga 1 s, durabilidade 96).
- Derrubar Árvores: com machado, quebra até 128 troncos conectados; agachar desativa.
- Fragmento Arcano: drop exclusivo com 12% de chance de mobs hostis.
- Receitas para os dois cajados em `assets/surpresa/recipes`.

## Compilar
Requer Java 8 e Gradle 4.10.3, com acesso à internet para baixar ForgeGradle/dependências:
`gradle --no-daemon clean build`

O JAR final fica em `build/libs/`.

## Compilar pelo Android
Envie o conteúdo desta pasta para um repositório GitHub. A workflow em
`.github/workflows/build.yml` executa a compilação na nuvem. Depois abra
Actions > Build Forge 1.12.2 > execução concluída > Artifacts e baixe
`surpresa-mod-forge-1.12.2`.

## Observações
Este projeto foi reconstruído a partir do código enviado. A compilação real
depende de executar o workflow/Gradle com acesso aos repositórios Maven.
